<?php
	$user =$_GET['name'];
	$pass =$_GET['pass'];

	if($user == 'leo' && $pass == '123456'){
		echo "{ok:1,data:'登录成功'}";
	}
	else{
		echo "{ok:0,data:'登录失败'}";
	}
	//echo "xuxunzhenshuai";

?>