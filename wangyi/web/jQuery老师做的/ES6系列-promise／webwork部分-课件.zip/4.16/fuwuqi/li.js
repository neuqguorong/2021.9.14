var arr = [];
this.onmessage = function(res){
	var data = res.data;
	arr.push(data);
	this.postMessage(arr);
	//var lastDate = data.charAt(0).toUpperCase()+data.substring(1);

	//this.postMessage(lastDate);
	/*
	setInterval(()=>{
		this.postMessage(Math.random())
	},1000);
*/
}
