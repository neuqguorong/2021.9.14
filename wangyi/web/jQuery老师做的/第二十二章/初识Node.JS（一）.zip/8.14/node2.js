//console.log('今天心情真好');
//console.log('我就想看看这个结果:'+(1+2));
var leo = 1;
if(leo == 1){
	console.log('今天天还挺热');
}
else{
	console.log('听凉快');
}