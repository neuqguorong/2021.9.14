var http = require('http');
http.createServer(function(request,response){


	
});

http.listen(9218);
